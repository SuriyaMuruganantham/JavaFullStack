package longestsubsequence;

public class Longestsequence {
public static int list(int arr[], int n)
{
	int list[] = new int[n];
	int i,j,maximum=0;
	
	for(i=0;i<n;i++)
		list[i]=1;
	
	for(i=1;i<n;i++)
	for(j=0;j<i;j++)
		
			if(arr[i]>arr[j] && list[i]<list[j]+1)
			
				list[i]=list[j]+1;
			
			for(i=0;i<n;i++)
			
				if(maximum<list[i])
				
					maximum=list[i];
				
					return maximum;
					
				
}
	public static void main(String[] args)throws Exception {
	int arr[]= {10,22,9,33,21,50,41,60};
	int n= arr.length;
	 
	System.out.println("The length of longest subsequence is"+" "+ list(arr,n));

	}	

}
