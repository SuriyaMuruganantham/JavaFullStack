

public class sorting {
	public static void main(String[] args) throws Exception
	{
		sorting.sort();
		sortarray.sort2();
	}	

public static void sort()
{
int n=4;
System.out.println("Sorting elements using compareTo method");
String name[]= {"Priya","Meera","Krishna","Sugnanya"};
String temp;
for(int i=0;i<n;i++) {
	for(int j=i+1;j<n;j++) {
		if(name[i].compareTo(name[j])>0) {
		temp= name[i];
        name[i]=name[j];
        name[j]= temp;
}
	}	
}
for(int i=0;i<n;i++)
{
	System.out.println(name[i]);
}
}
}