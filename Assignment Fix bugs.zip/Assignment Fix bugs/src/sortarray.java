import java.util.Arrays;

public class sortarray extends sorting {
	public static void sort2()
	{
		int n=4;
		System.out.println("Sorting elements using array sort method");
		String name[]= {"Priya","Meera","Krishna","Sugnanya"};
	    Arrays.sort(name);
	    System.out.println("The sorted elements");
	    for(int i=0;i<n;i++)
	    {
	    	System.out.println(name[i]);
	    }
	    }
	}





