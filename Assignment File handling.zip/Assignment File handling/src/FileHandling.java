import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileHandling {
	public static void main(String args[]) throws IOException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		
		int operations= sc.nextInt();
		switch(operations)
		{
		case 1:
			createfile();
		break;
		case 2:
			Writefile();
		break;
		case 3:
			Readfile();
		break;
		case 4:
			Appendfile();
		default:
	    System.out.println("Exist");
		}
		sc.close();
	}
public static void createfile()throws IOException 
{
	File file = new File("C:\\Users\\SundeepHarini\\Desktop\\java program\\hello.txt");
	if(file.createNewFile())
	{
		System.out.println("File created" +file.getName());
	}
		else {
			System.out.println("File already exists" +file.getName());
	}
}
public static void Writefile() throws IOException
{
	FileWriter writer = new FileWriter("C:\\Users\\SundeepHarini\\Desktop\\java program\\hello.txt");
	writer.write("Hello world");
	writer.close();
	System.out.println("Successfully worte to the file");
}
public static void Readfile() throws IOException
{
	File reader= new File("C:\\Users\\SundeepHarini\\Desktop\\java program\\hello.txt");
	Scanner myReader = new Scanner(reader);
	while(myReader.hasNextLine()) {
		String data = myReader.nextLine();
		System.out.println(data);
	}
	myReader.close();
}
public static void Appendfile() throws IOException
	{
		BufferedWriter out = new BufferedWriter(new FileWriter("C:\\Users\\SundeepHarini\\Desktop\\java program\\hello.txt"));
		out.write("welcome");
		out.close();
		out = new BufferedWriter(new FileWriter("C:\\Users\\SundeepHarini\\Desktop\\java program\\hello.txt",true));
		out.write("world");
		out.close();
		BufferedReader in = new BufferedReader(new FileReader("C:\\Users\\SundeepHarini\\Desktop\\java program\\hello.txt"));
		String str;
		while((str = in.readLine())!=null) {
			System.out.println(str);
		}
in.close();
}
}


