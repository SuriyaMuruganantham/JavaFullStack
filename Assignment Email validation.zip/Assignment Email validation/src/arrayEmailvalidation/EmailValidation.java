package arrayEmailvalidation;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidation {
	public static void main(String[] args)
	{
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("abc@gmail.com");
		list.add("java123@gmail.com");
		list.add("priya309@yahoo.com");
		list.add("Siva67@gmail.com");
		list.add("MahimaSiva56@gmail.com");
		list.add("Vasav54@yahoo.com");
		list.add("simple25@gmail.com");
		list.add("colorpink@gmail.com");
		list.add("moonsun10@yahoo.com");
		list.add("pavirani@gmail.com");
		
		System.out.println("Email id's sucessfully added to the array list");
		System.out.println(list);
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter your Email id");
		String userInput = sc2.next();
		
		 for(String i: list) {
			
			if(i.equals(userInput)) 
			System.out.println("Entered email id is stored in the array VALID for login");
			
			else
				
			System.out.println("Entered email id is not stored in the array INVALID for login");
			
			break;
		 }
			String pattern = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
			Pattern p = Pattern.compile(pattern);
			Matcher m = p.matcher(userInput);
			
			if(m.matches())
			{
				System.out.println("Regular Expression validation of email id");
				System.out.println("Renter your email id");
				String String = sc2.next();
			if(String.equals(userInput)) {
				
			System.out.println("Mail id format matches");
			}
			else
			{
			System.out.println("Mail id format is incorrect please enter correct format");
			}
			
			}
			EmailValidation.password();
			sc2.close();
			}
				 		 
	
public static void password()
{
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Regular expression validation of password");		
		System.out.println("Create your password");
		String userPassword = sc.next();
		String pattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&+=]).{6,20}";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(userPassword);
		if(m.matches())
		{
			System.out.println("You have sucessfully created your password");
		}
		else
		{
			System.out.println("You have to follow the instructions to create password");
			System.out.println("1.Your password must contain atleast one uppercase letter");
			System.out.println("2.Your password must contain atleast one lowercase letter");
			System.out.println("3.Your password must contain atleast one number");
			System.out.println("4.Your password must contain special character");
			System.out.println("5.Your password should be minimum of 8 digit and maximum of 10 digit");
		
		}
		sc.close();
}
}
}
